<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller {
    public function index(){

        $this->display();

    }

    public function vote(){
        if($_SESSION['user']!=1){
            $this->error('you have not login!',U('Home/User/login'));
        }
    }

}