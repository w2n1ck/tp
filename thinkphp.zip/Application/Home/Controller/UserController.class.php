<?php
namespace Home\Controller;
use Think\Controller;
class UserController extends Controller {
    public function index(){

    	echo "hello world";

    }

    function test(){
    	cas_login('1120131205','200214');

    }

    public function login(){
    	if(isset($_POST['uid'])&&isset($_POST['password'])){
        	$uid=I('POST.uid',0,'intval');
        	$password=I('POST.password',0);
        	if(!query_user_exist($uid)){
        		$info=cas_login($uid,$password);
        		insert_user_info($info);
        	}
        	if($password===query_pass_by_uid($uid)){
                session_start();
                $_SESSION['user']=$uid;
                $this->success('login success!', U('index'),1);
            }
           $this->error('username or password error!',U('login'));
           session_destroy();
        }else{
            $this->display();
        }

    }

}