<?php
namespace Home\Controller;
use Think\Controller;
class AdminController extends Controller {
    public function index(){
      echo U('Home/Admin/index');



    }

    public function user_info($uid){


    }

    public function  ban_user($uid){


    }

    public function reban_user($uid){

    }

    public function  send_brocast_message(){

    }

    public function admin_login_log(){
        
    }


    


    public function admin_login(){
        $username=C('admin_user');
        $password=C('admin_pass');
        //echo $username,$password;
        if(isset($_POST['username'])){
            if($username===$_POST['username']&&$password===$_POST['password']){
                session_start();
                $_SESSION['admin']=1;
                 $this->success('login success!', U('index'),1);
                 write_admin_ip_log(I('SERVER.REMOTE_ADDR','0'));
            }
           $this->error('username or password error!',U('admin_login'));
           session_destroy();
        }else{
            $this->display();
        }
    }
}