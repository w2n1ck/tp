<?php
function write_admin_ip_log($ip){
	$admin=array(
            'donate_username'=>'0',
			'admin_login_ip'=>$ip,
            );
        M('admin')->add($admin);
        //dump(M('admin')->where("admin_login_ip<>'0'")->select());
}

function query_pass_by_uid($uid){
	return M('user')->field('password')->where(array('uid'=>$uid))->select();
}

function query_user_exist($uid){
	 if(M('user')->field('password')->where(array('uid'=>$uid))->select()){
	 	return 1;
	 }
	 return 0;
}


