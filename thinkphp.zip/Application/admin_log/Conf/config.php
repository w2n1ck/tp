<?php
return array(
	'admin_user' => 'root',
	'admin_pass' =>  'godness_of_bit',
	'VIEW_PATH'  =>  '/tp/html/admin_login.html'
);